<!DOCTYPE html>
<html lang="en"><head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <title>TOTAL DE CIUDADANOS CAPTURADOS POR COORDINADOR</title>
  <meta name="description" content="Reporte de Totales">
  <meta name="author" content="JOSE COTA">
 
  	
  <!-- Stylesheets -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <!-- Font awesome icon -->
  <link rel="stylesheet" href="css/font-awesome.min.css"> 
  <!-- jQuery UI -->
  <link rel="stylesheet" href="css/jquery-ui.css"> 
  <!-- Calendar -->
  <link rel="stylesheet" href="css/fullcalendar.css">
  <!-- prettyPhoto -->
  <link rel="stylesheet" href="css/prettyPhoto.css">  
  <!-- Star rating -->
  <link rel="stylesheet" href="css/rateit.css">
  <!-- Date picker -->
  <link rel="stylesheet" href="css/bootstrap-datetimepicker.min.css">
  <!-- CLEditor -->
  <link rel="stylesheet" href="css/jquery.cleditor.css"> 
  <!-- Data tables -->
  <link rel="stylesheet" href="css/jquery.dataTables.css"> 
  <!-- Bootstrap toggle -->
  <link rel="stylesheet" href="css/jquery.onoff.css">
  <!-- Main stylesheet -->
  <link href="css/style-dashboard.css" rel="stylesheet">
  <!-- Widgets stylesheet -->
  <link href="css/widgets.css" rel="stylesheet"> 
  
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
      
	<style type="text/css">		
		@media screen and (min-width: 768px) {
			#mapa_content {width:100%; height:450px;}
			#modalFlotante .modal-dialog  {width:40%;}
		}
		
		body{
			background:transparent;
			text-align=center;
			font-family:Arial, Helvetica, sans-serif;
		}
		
	</style>

  <!--[if lt IE 9]>
  <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
  <![endif]-->
  
  <script type="text/javascript"> 
	function imprimir(){
		document.all.btnImprimir.style.display='none';	
		document.all.btnRegresar.style.display='none';	
		window.print();
		document.all.btnImprimir.style.display='inline';
		//document.all.btnImprimir.style.text-align='center';
		
		document.all.btnRegresar.style.display='inline';	
		//document.all.btnRegresar.style.text-align='center';
	}  
  </script>
</head>
<body>
  <div class="col-md-6 style="padding:0px">
	<p style="text-align:center;">
		<img src="img/logo-top.png"><br>
		<strong>AUDITORÍA SUPERIOR DE LA CIUDAD DE MÉXICO<br>
		Av. 20 de Noviembre No. 700 Col. Huichapan, Barrio San Marcos. C.P. 16050, Del. Xochimilco, México, D.F. Tel. +52 (55) 5624–5100 
		</strong><br><br>
		REPORTE GENERAL
	</p>
		<?php		
			$nTotalRegistros=0;
			$sql = "SELECT concat(u.nombre, ' ', u.paterno) usr,  count(*) cantidad " .
			"FROM sce_electores e INNER JOIN sce_usuarios u on e.usrAlta=u.idUsuario " .
			"GROUP BY concat(u.nombre, ' ', u.paterno) " .
			"ORDER By 2 desc";
							
			mysql_connect("localhost", "usrAudi", ".usraudiCota13.");
			mysql_select_db("ascm_sia");
			$query = mysql_query($sql);

			echo "<table class='table table-striped table-bordered table-condensed'>";
			echo "<thead><tr><th>COORDINADOR</th><th>CANTIDAD</th></thead><tbody>";
			while($row = mysql_fetch_array($query)){
				echo "<tr>";
				echo "<td>".$row['usr']."</td>";
				echo "<td>".$row['cantidad']."</td>";
				echo "</tr>";
				
				$nTotalRegistros = $nTotalRegistros + $row['cantidad'];
				
			}
			echo "<tr><td style='text-align:right'><b>Registros Capturados:</b> </td><td><b>". $nTotalRegistros . "</b></td></tr>".
			"</tbody></table>";
		?> 
		<br>
		<div class="col-md-4 style="padding:0px"></div>
		<div class="col-md-2 style="padding:0px">
			<p style="text-align:right; width:100%" style="display:inline" id="btnRegresar">
				<button  onclick="javascript:window.close();" class="btn btn-link btn-lg">
					<span class="glyphicon glyphicon-circle-arrow-left"></span> Cerrar
				</button>
			</p>			
		</div>
		<div class="col-md-2 style="padding:0px">
			<p style="text-align:right; width:100%" style="display:inline" id="btnImprimir">
				<button  onclick="javascript:imprimir();" class="btn btn-link btn-lg">
					<span class="glyphicon glyphicon-print"></span> Imprimir
				</button>
			</p>			
		</div>
		<div class="col-md-4 style="padding:0px"></div>			
		

	
	</div>	
	</div>
	<div class="col-md-6 style="padding:0px">
	
	</div>
  
  
</body>
</html>

