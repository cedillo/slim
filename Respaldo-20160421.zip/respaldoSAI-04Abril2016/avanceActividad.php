
<!DOCTYPE html>
<!-- saved from url=(0035)http://ashobiz.asia/mac52/macadmin/ -->
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">  
  <meta charset="utf-8">
		<script type="text/javascript" src="js/canvasjs.min.js"></script>
		<script type='text/javascript' src="http://ajax.googleapis.com/ajax/libs/jquery/1.5.1/jquery.min.js?ver=3.1.2"></script> 
	
  	<style type="text/css">		
		@media screen and (min-width: 768px) {
			#mapa_content {width:100%; height:150px;}
			#canvasJG, #canvasJD, #canvasDIP{height:175px; width:100%;}			
			#modalHoja .modal-dialog  {width:50%;}
			
			.auditor{background:#f4f4f4; font-size:6pt; padding:7px; display:inline; margin:1px; border:1px gray solid;}
			
			label {text-align:right;}
			
.auditor[type=checkbox] {
    content: "\2713";
    text-shadow: 1px 1px 1px rgba(0, 0, 0, .2);
    font-size: 15px;
    color: #f3f3f3;
    text-align: center;
    line-height: 15px;
}
			
			
		}
	</style>
  
  <script type="text/javascript"> 
	var mapa;
	var nZoom=10;
	

	
	
	window.onload = function () {
		var chart = new CanvasJS.Chart("canvasJG", {
			title:{ text: "TIPOS DE ARCHIVOS", fontColor: "#2f4f4f",fontSize: 10,verticalAlign: "top", horizontalAlign: "center" },
			axisX: {labelFontSize: 10,labelFontColor: "black", tickColor: "red",tickLength: 5,tickThickness: 2},		
			animationEnabled: true,
			//legend: {verticalAlign: "bottom", horizontalAlign: "center" },
			theme: "theme1", 
		  data: [
		  {        
			//color: "#B0D0B0",
			indexLabelFontSize: 10,indexLabelFontColor:"black",type: "pie",bevelEnabled: true,				
			//indexLabel: "{y}",
			showInLegend: false,legendMarkerColor: "gray",legendText: "{indexLabel} {y}",			
			dataPoints: [  				
			{y: 59, indexLabel: "CONTRATOS 59"}, {y: 21,  indexLabel: "SOLICITUDES 21" }, {y: 31,  indexLabel: "PROCEDIMIENTOS 31" }
			]
		  }   
		  ]
		});
		chart.render();

		var chart2 = new CanvasJS.Chart("canvasJD", {
			title:{ text: "ESTATUS DE ACOPIO", fontColor: "#2f4f4f",fontSize: 10,verticalAlign: "top", horizontalAlign: "center" },
			axisX: {labelFontSize: 10,labelFontColor: "black", tickColor: "red",tickLength: 5,tickThickness: 2},		
			animationEnabled: true,
			//legend: {verticalAlign: "bottom", horizontalAlign: "center" },
			theme: "theme1", 
		  data: [
		  {        
			//color: "#B0D0B0",
			indexLabelFontSize: 10,indexLabelFontColor:"black",type: "pie",bevelEnabled: true,				
			//indexLabel: "{y}",
			showInLegend: false,legendMarkerColor: "gray",legendText: "{indexLabel} {y}",			
			dataPoints: [  				
			{y: 59, indexLabel: "DESDE CENTRALES 5"}, {y: 21,  indexLabel: "REMOTO 21"}, {y: 21,  indexLabel: "POR AUDITORES 70"}
			]
		  }   
		  ]
		});
		chart2.render();			
	  };

	var ventana;
	
	function modalWin(sPagina) {
		var sDimensiones; 
		
		if (window.showModalDialog) {
			sDimensiones= "dialogWidth:" + window.innerWidth + "px;dialogHeight:" + window.innerHeight + "px;";
			window.showModalDialog(sPagina,"Reporte",sDimensiones);
		} 
		else {
			sDimensiones= "width=" + window.innerWidth + ", height=" + window.innerHeight + ",location=no, titlebar=no, menubar=no,minimizable=no, resizable=no,  toolbar=no,directories=no,status=no,continued from previous linemenubar=no,scrollbars=no,resizable=no ,modal=yes";
			ventana = window.open(sPagina,'Reporte', sDimensiones);
			ventana.focus();
		}
	}	
	
	
	
	
	$(document).ready(function(){	
	
		$( "#btnGuardar" ).click(function() {
			$('#modalHoja').modal('hide');
		});
		
		
		$( "#btnRegresar" ).click(function() {
			document.all.listasAuditoria.style.display='inline';
			document.all.capturaAuditoria.style.display='none';		
		});
		
		$( "#btnTurnar" ).click(function() {
			document.all.capturaDocto.style.display='none';
			document.all.turnaDocto.style.display='inline';
			
			document.all.btnGuardarEnviar.style.display='inline';
			document.all.btnGuardar.style.display='none';
			document.all.btnTurnar.style.display='none';
		});
		
		$( "#btnGuardarEnviar" ).click(function() {
			alert("Guardando y enviando");
			document.all.capturaDocto.style.display='inline';
			document.all.turnaDocto.style.display='none';
			
			document.all.btnGuardarEnviar.style.display='none';
			document.all.btnGuardar.style.display='inline';
			document.all.btnTurnar.style.display='inline';

			$('#modalHoja').modal('hide');
			
			

		});
		$( "#btnCancelar" ).click(function() {
			document.all.capturaDocto.style.display='inline';
			document.all.turnaDocto.style.display='none';

			document.all.btnGuardarEnviar.style.display='none';
			document.all.btnGuardar.style.display='inline';
			document.all.btnTurnar.style.display='inline';
			
			$('#modalHoja').modal('hide');
		});
		
		
		$( "#btnLigarDocto" ).click(function() {		
			$( "#btnUpload" ).click(); 
		});

		$( "#btnAnexarDocto" ).click(function() {		
			$( "#btnUpload" ).click(); 
		});	
		$( "#btnNuevoDocto" ).click(function() {
			$('#modalDocto').removeClass("invisible");
			$('#modalDocto').modal('toggle');
			$('#modalDocto').modal('show');						
		});
		$( "#btnCancelarDocto" ).click(function() {
			$('#modalDocto').modal('hide');
		});
		$( "#btnGuardarDocto" ).click(function() {
			$('#modalDocto').modal('hide');
		});		
		
		$( "#btnNuevoDictamen" ).click(function() {
			$('#modalDictamen').removeClass("invisible");
			$('#modalDictamen').modal('toggle');
			$('#modalDictamen').modal('show');						
		});
		$( "#btnCancelarDictamen" ).click(function() {
			$('#modalDictamen').modal('hide');
		});
		$( "#btnGuardarDictamen" ).click(function() {
			$('#modalDictamen').modal('hide');
		});			
		
	
	});
	
	
    </script>
  
  
  <!-- Title and other stuffs -->
  <title>Sistema Integral de Auditorias</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="keywords" content="">
  <meta name="author" content="">

  <!-- Stylesheets -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <!-- Font awesome icon -->
  <link rel="stylesheet" href="css/font-awesome.min.css"> 
  <!-- jQuery UI -->
  <link rel="stylesheet" href="css/jquery-ui.css"> 
  <!-- Calendar -->
  <link rel="stylesheet" href="css/fullcalendar.css">
  <!-- prettyPhoto -->
  <link rel="stylesheet" href="css/prettyPhoto.css">  
  <!-- Star rating -->
  <link rel="stylesheet" href="css/rateit.css">
  <!-- Date picker -->
  <link rel="stylesheet" href="css/bootstrap-datetimepicker.min.css">
  <!-- CLEditor -->
  <link rel="stylesheet" href="css/jquery.cleditor.css"> 
  <!-- Data tables -->
  <link rel="stylesheet" href="jquery.dataTables.css"> 
  <!-- Bootstrap toggle -->
  <link rel="stylesheet" href="css/jquery.onoff.css">
  <!-- Main stylesheet -->
  <link href="css/style-dashboard.css" rel="stylesheet">
  <!-- Widgets stylesheet -->
  <link href="css/widgets.css" rel="stylesheet">   
  
  <script src="./Dashboard - MacAdmin_files/respond.min.js"></script>
  <!--[if lt IE 9]>
  <script src="js/html5shiv.js"></script>
  <![endif]-->

  <!-- Favicon -->
  <link rel="shortcut icon" href="img/favicon.png">


<body>
	<div class="navbar navbar-fixed-top bs-docs-nav" role="banner">  
			<div class="container">
				<!-- Navigation starts -->
				<nav class="collapse navbar-collapse bs-navbar-collapse" role="navigation">			
					<div class="col-xs-12">
						<div class="col-xs-3"><a href="/"><img src="img/logo-top.png"></a></div>				
						<div class="col-xs-3">
							<ul class="nav navbar-nav "><li><a href="#"><i class="fa fa-th-list"></i> <?php echo $_SESSION["sCampanaActal"] ?></a></li></ul>
						</div>
						<div class="col-xs-3">
							<ul class="nav navbar-nav "><li><a href="./notificaciones"><i class="fa fa-envelope-o"></i> Tienes (3) Mensajes nuevos</a></li></ul>
						</div>
						<div class="col-xs-3">
						<ul class="nav navbar-nav  pull-right">
							<li class="dropdown pull-right">            
								<a data-toggle="dropdown" class="dropdown-toggle" href="/">
									<i class="fa fa-user"></i> <b>C. <?php echo $_SESSION["sUsuario"] ?></b> <b class="caret"></b> 							
								</a>
								<ul class="dropdown-menu">
								  <li><a href="./perfil"><i class="fa fa-user"></i> Perfil</a></li>
								  <li><a href="./cerrar"><i class="fa fa-sign-out"></i> Salir</a></li>
								</ul>
							</li>
							</ul>						
						</div>				
					</div>
				</nav>
			</div>
	</div>



<!-- Main content starts -->

<div class="content">
  	<div class="panel panel-default">
			<div class="panel-body">
	  			<div class="row">
					<br>
					<div class="col-xs-6">
						<div class="form-group">							
							<div class="col-xs-6"><div id="canvasJG" ></div></div>						
							<div class="col-xs-6"><div id="canvasJD" ></div></div>
						</div>
						<div class="clearfix"></div>						
						<div class="widget">
							<div class="widget-head">
							  <div class="pull-left">Registrar Actividad por Auditoría</div>
							  <div class="clearfix"></div>
							</div>              
							<div class="widget-content">
								<br>
								<div class="form-group">
									<label class="col-xs-3 control-label">Sujeto</label>
									<div class="col-xs-9">
										<select class="form-control" name="txtNivel">
											<option value="">Seleccione...</option>
											<option value="" SELECTED>SECRETARÍA DE OBRAS Y SERVICIOS</option>
										</select>
									</div>
								</div>									
								
								<br>
								<div class="form-group">									
									<label class="col-xs-3 control-label">Auditoría</label>
									<div class="col-xs-9">
										<select class="form-control" name="txtNivel">
											<option value="">Seleccione</option>
											<option value="" Selected>ASCM/00123/14 OBRA</option>											
											<option value="">ASCM/00124/14 DESEMPEÑO</option>											
											<option value="">ASCM/00125/14 FINANCIERA</option>											

										</select>
									</div>									
								</div>									
								
								<br>
								<div class="form-group">									
									<label class="col-xs-3 control-label">Objeto</label>
									<div class="col-xs-9">
										<select class="form-control" name="txtNivel" READONLY>
											<option value="">Seleccione</option>
											<option value="" selected>CAPÍTULO 6000 "INVERSIÓN PÚBLICA" (HOSPITAL VETERINARIO DELEGACIÓN IZTAPALAPA)</option>
										</select>
									</div>									
								</div>
								<br>
								<div class="form-group">
									<label class="col-xs-3 control-label">Fase</label>
									<div class="col-xs-9">
										<select class="form-control" name="txtNivel">
											<option value="">Seleccione...</option>
											<option value="">PLANEACIÓN</option>
											<option value="" Selected>EJECUCIÓN</option>
											<option value="">ELABORACIÓN DE INFORMES</option>
										</select>
									</div>
								</div>	
								<br>							
								<div class="form-group">							
									<label class="col-xs-3 control-label">Actividad</label>
									<div class="col-xs-9">
										<select class="form-control" name="txtNivel">
											<option value="">Seleccione...</option>
											<option value="" SELECTED>PRESENTACIÓN DEL PERSONAL</option>
											<option value="">REVISIÓN</option>
											<option value="">ANÁLISIS</option>
											<option value="">DISEÑO</option>
											<option value="">EJECUCIÓN</option>
											<option value="">ACCIONES</option>
											<option value="">CONCLUSIÓN</option>
										</select>
									</div>																		
								</div>		
								<br>							
								<div class="form-group">								
									<label class="col-xs-3 control-label">Observaciones</label>
									<div class="col-xs-9">
										<input type="text" class="form-control" name="txtElector"/>
									</div>																								
								</div>	
								<br>
								<div class="form-group">								
									<label class="col-xs-3 control-label">Porcentaje Acumulado</label>
									<div class="col-xs-3">
										<input type="text" class="form-control" name="txtElector"/>
									</div>	
									
									<label class="col-xs-3 control-label">Semanas Acumuladas</label>
									<div class="col-xs-3">
										<input type="text" class="form-control" name="txtElector"/>
									</div>															
								</div>								
								<br>	
								<div class="clearfix"></div>
							</div>
							<div class="widget-foot">
								<button type="button" class="btn btn-primary  btn-xs" 	id="btnLigarDocto"><i class="fa fa-floppy-o"></i> Guardar</button>
								<button type="button" class="btn btn-default  btn-xs" 	id="btnLigarDocto"><i class="fa fa-eraser"></i> Limpiar campos</button>
								<div class="clearfix"></div>
							</div>
						</div>						
					</div>
					
					<div class="col-xs-6">
						<div class="widget">
							<div class="widget-head">
							  <div class="pull-left"><h3 class="modal-title"><i class="fa fa-tasks"></i> Avance de Actividades por Auditoría</h3></div>
							  <div class="widget-icons pull-right">
								<a href="#" class="wminimize"><i class="fa fa-chevron-up"></i></a> 						
							  </div>  
							  <div class="clearfix"></div>
							</div>             
							<div class="widget-content">
								<div class="table-responsive" style="height: 500px; overflow: auto; overflow-x:hidden;">
									<table class="table table-striped table-bordered table-hover">
									  <thead>
										<tr><th>Clave Auditoría</th><th>Sujeto de Fiscalización</th><th>Tipo de Auditoría</th><th>ID</th><th>Fecha</th><th>Porcentaje</th><th>Estatus</th><th>Anexo(s)</th></tr>
									  </thead>
									  <tbody>									  
											<tr style="width: 100%; font-size: xx-small">
												<td>ASCM-DGL-001/14</td><td>SECRETARÍA DE OBRAS Y SERVICIOS</td><td>OBRA PÚBLICA</td><td>AV-0023</td><td>11/03/2016</td><td>100%</td><td>TERMINADA</td><td><img onclick="modalWin('mostrarPDF.php');" src="img/xls.gif"></td>
											</tr>
											<tr style="width: 100%; font-size: xx-small">
												<td>ASCM-DGL-001/14</td><td>SECRETARÍA DE OBRAS Y SERVICIOS</td><td>OBRA PÚBLICA</td><td>AV-0022</td><td>04/03/2016</td><td>90%</td><td>PROCESO</td><td><img onclick="modalWin('mostrarPDF.php');" src="img/pdf.gif"></td>
											</tr>
											<tr style="width: 100%; font-size: xx-small">
												<td>ASCM-DGL-001/14</td><td>SECRETARÍA DE OBRAS Y SERVICIOS</td><td>OBRA PÚBLICA</td><td>AV-0021</td><td>24/02/2016</td><td>70%</td><td>PROCESO</td><td><img onclick="modalWin('mostrarPDF.php');" src="img/pdf.gif"></td>
											</tr>
											<tr style="width: 100%; font-size: xx-small">
												<td>ASCM-DGL-001/14</td><td>SECRETARÍA DE OBRAS Y SERVICIOS</td><td>OBRA PÚBLICA</td><td>AV-0020</td><td>10/02/2016</td><td>55%</td><td>PROCESO</td><td><img onclick="modalWin('mostrarPDF.php');" src="img/xls.gif"></td>
											</tr>
											
											<tr style="width: 100%; font-size: xx-small">
												<td>ASCM-DGL-001/14</td><td>SECRETARÍA DE OBRAS Y SERVICIOS</td><td>OBRA PÚBLICA</td><td>AV-0019</td><td>01/02/2016</td><td>35%</td><td>PROCESO</td><td><img onclick="modalWin('mostrarPDF.php');" src="img/xls.gif"></td>
											</tr>

											<tr style="width: 100%; font-size: xx-small">
												<td>ASCM-DGL-001/14</td><td>SECRETARÍA DE OBRAS Y SERVICIOS</td><td>OBRA PÚBLICA</td><td>AV-0018</td><td>15/01/2016</td><td>15%</td><td>PROCESO</td><td><img onclick="modalWin('mostrarPDF.php');" src="img/xls.gif"></td>
											</tr>

											<tr style="width: 100%; font-size: xx-small">
												<td>ASCM-DGL-001/14</td><td>SECRETARÍA DE OBRAS Y SERVICIOS</td><td>OBRA PÚBLICA</td><td>AV-0017</td><td>10/01/2016</td><td>5%</td><td>PROCESO</td><td><img onclick="modalWin('mostrarPDF.php');" src="img/xls.gif"></td>
											</tr>																							
									  </tbody>
									</table>
								</div>
							</div>
						</div>				
					</div>
				</div>
			</div>
	</div>
				
</div>


<!-- Content ends -->


<!-- Footer starts -->
<footer>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
            <!-- Copyright info -->
		<p class="copy">Copyright © 2016 | Auditoría Superior de la Ciudad de México</p>
      </div>
    </div>
  </div>
</footer> 	

<!-- Footer ends -->

<!-- Scroll to top -->
<span class="totop" style="display: none;"><a href="#"><i class="fa fa-chevron-up"></i></a></span> 

<!-- JS -->
<script src="./Dashboard - MacAdmin_files/jquery.js"></script> <!-- jQuery -->
<script src="./Dashboard - MacAdmin_files/bootstrap.min.js"></script> <!-- Bootstrap -->
<script src="./Dashboard - MacAdmin_files/jquery-ui.min.js"></script> <!-- jQuery UI -->
<script src="./Dashboard - MacAdmin_files/moment.min.js"></script> <!-- Moment js for full calendar -->
<script src="./Dashboard - MacAdmin_files/fullcalendar.min.js"></script> <!-- Full Google Calendar - Calendar -->
<script src="./Dashboard - MacAdmin_files/jquery.rateit.min.js"></script> <!-- RateIt - Star rating -->
<script src="./Dashboard - MacAdmin_files/jquery.prettyPhoto.js"></script> <!-- prettyPhoto -->
<script src="./Dashboard - MacAdmin_files/jquery.slimscroll.min.js"></script> <!-- jQuery Slim Scroll -->
<script src="./Dashboard - MacAdmin_files/jquery.dataTables.min.js"></script> <!-- Data tables -->

<!-- jQuery Flot -->
<script src="./Dashboard - MacAdmin_files/excanvas.min.js"></script>
<script src="./Dashboard - MacAdmin_files/jquery.flot.js"></script>
<script src="./Dashboard - MacAdmin_files/jquery.flot.resize.js"></script>
<script src="./Dashboard - MacAdmin_files/jquery.flot.pie.js"></script>
<script src="./Dashboard - MacAdmin_files/jquery.flot.stack.js"></script>

<!-- jQuery Notification - Noty -->
<script src="./Dashboard - MacAdmin_files/jquery.noty.js"></script> <!-- jQuery Notify -->
<script src="./Dashboard - MacAdmin_files/default.js"></script> <!-- jQuery Notify -->
<script src="./Dashboard - MacAdmin_files/bottom.js"></script> <!-- jQuery Notify -->
<script src="./Dashboard - MacAdmin_files/topRight.js"></script> <!-- jQuery Notify -->
<script src="./Dashboard - MacAdmin_files/top.js"></script> <!-- jQuery Notify -->
<!-- jQuery Notification ends -->

<script src="./Dashboard - MacAdmin_files/sparklines.js"></script> <!-- Sparklines -->
<script src="./Dashboard - MacAdmin_files/jquery.cleditor.min.js"></script> <!-- CLEditor -->
<script src="./Dashboard - MacAdmin_files/bootstrap-datetimepicker.min.js"></script> <!-- Date picker -->
<script src="./Dashboard - MacAdmin_files/jquery.onoff.min.js"></script> <!-- Bootstrap Toggle -->
<script src="./Dashboard - MacAdmin_files/filter.js"></script> <!-- Filter for support page -->
<script src="./Dashboard - MacAdmin_files/custom.js"></script> <!-- Custom codes -->
<script src="./Dashboard - MacAdmin_files/charts.js"></script> <!-- Charts & Graphs -->

</body></html>



<div id="modalHoja" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<form id="formulario" METHOD='POST' action='/guardar/intencion' role="form" onsubmit="return validarEnvio();">
			<input type='HIDDEN' name='txtValores' value=''>								
			<!-- Modal content-->
			<div class="modal-content">									
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title">Registrar auditoría...</h4>
				</div>									
				<div class="modal-body">
					<div class="clearfix"></div>
				</div>
				
				<div class="modal-footer">
					<button  type="button" class="btn btn-primary active" id="btnGuardar" 		style="display:inline;">Guardar</button>	
					<button  type="button" class="btn btn-default active" id="btnCancelar" 		style="display:inline;">Cancelar</button>	
				</div>
			</div>		
		</form>
					
	</div>
</div>