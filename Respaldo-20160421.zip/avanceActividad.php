
<!DOCTYPE html>
<!-- saved from url=(0035)http://ashobiz.asia/mac52/macadmin/ -->
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">  
  <meta charset="utf-8">
		<script type="text/javascript" src="js/canvasjs.min.js"></script>
		<script type='text/javascript' src="http://ajax.googleapis.com/ajax/libs/jquery/1.5.1/jquery.min.js?ver=3.1.2"></script>
		<script type="text/javascript" src="js/genericas.js"></script>
	
  	<style type="text/css">		
		@media screen and (min-width: 768px) {
			#mapa_content {width:100%; height:150px;}
			#canvasJG, #canvasJD, #canvasDIP{height:175px; width:100%;}			
			#modalAvance .modal-dialog  {width:50%;}
			.auditor{background:#f4f4f4; font-size:6pt; padding:7px; display:inline; margin:1px; border:1px gray solid;}
			
			label {text-align:right;}
			
.auditor[type=checkbox] {
    content: "\2713";
    text-shadow: 1px 1px 1px rgba(0, 0, 0, .2);
    font-size: 15px;
    color: #f3f3f3;
    text-align: center;
    line-height: 15px;
}
			
			
		}
	</style>
  
  <script type="text/javascript"> 
	var mapa;
	var nZoom=10;
	

	
	
	window.onload = function () {
		var chart = new CanvasJS.Chart("canvasJG", {
			title:{ text: "TIPOS DE ARCHIVOS", fontColor: "#2f4f4f",fontSize: 10,verticalAlign: "top", horizontalAlign: "center" },
			axisX: {labelFontSize: 10,labelFontColor: "black", tickColor: "red",tickLength: 5,tickThickness: 2},		
			animationEnabled: true,
			//legend: {verticalAlign: "bottom", horizontalAlign: "center" },
			theme: "theme1", 
		  data: [
		  {        
			//color: "#B0D0B0",
			indexLabelFontSize: 10,indexLabelFontColor:"black",type: "pie",bevelEnabled: true,				
			//indexLabel: "{y}",
			showInLegend: false,legendMarkerColor: "gray",legendText: "{indexLabel} {y}",			
			dataPoints: [  				
			{y: 59, indexLabel: "CONTRATOS 59"}, {y: 21,  indexLabel: "SOLICITUDES 21" }, {y: 31,  indexLabel: "PROCEDIMIENTOS 31" }
			]
		  }   
		  ]
		});
		chart.render();

		var chart2 = new CanvasJS.Chart("canvasJD", {
			title:{ text: "ESTATUS DE ACOPIO", fontColor: "#2f4f4f",fontSize: 10,verticalAlign: "top", horizontalAlign: "center" },
			axisX: {labelFontSize: 10,labelFontColor: "black", tickColor: "red",tickLength: 5,tickThickness: 2},		
			animationEnabled: true,
			//legend: {verticalAlign: "bottom", horizontalAlign: "center" },
			theme: "theme1", 
		  data: [
		  {        
			//color: "#B0D0B0",
			indexLabelFontSize: 10,indexLabelFontColor:"black",type: "pie",bevelEnabled: true,				
			//indexLabel: "{y}",
			showInLegend: false,legendMarkerColor: "gray",legendText: "{indexLabel} {y}",			
			dataPoints: [  				
			{y: 59, indexLabel: "DESDE CENTRALES 5"}, {y: 21,  indexLabel: "REMOTO 21"}, {y: 21,  indexLabel: "POR AUDITORES 70"}
			]
		  }   
		  ]
		});
		chart2.render();			
	  };

	var ventana;
	
	function modalWin(sPagina) {
		var sDimensiones; 
		
		if (window.showModalDialog) {
			sDimensiones= "dialogWidth:" + window.innerWidth + "px;dialogHeight:" + window.innerHeight + "px;";
			window.showModalDialog(sPagina,"Reporte",sDimensiones);
		} 
		else {
			sDimensiones= "width=" + window.innerWidth + ", height=" + window.innerHeight + ",location=no, titlebar=no, menubar=no,minimizable=no, resizable=no,  toolbar=no,directories=no,status=no,continued from previous linemenubar=no,scrollbars=no,resizable=no ,modal=yes";
			ventana = window.open(sPagina,'Reporte', sDimensiones);
			ventana.focus();
		}
	}
	
	function validarAvance(){
		if (document.all.txtSujeto.selectedIndex==0){
			alert("Debe seleccionar el SUJETO DE FISCALIZACIÓN.");
			document.all.txtFaseActividad.focus();
			return false;
		}
		if (document.all.txtObjeto.selectedIndex==0){
			alert("Debe seleccionar el OBJETO DE FISCALIZACIÓN.");
			document.all.txtObjeto.focus();
			return false;
		}
		
		if (document.all.txtAuditoria.selectedIndex==0){
			alert("Debe seleccionar la AUDITORÍA.");
			document.all.txtAuditoria.focus();
			return false;
		}

		if (document.all.txtFase.selectedIndex==0){
			alert("Debe seleccionar la FASE.");
			document.all.txtFase.focus();
			return false;
		}

		if (document.all.txtActividad.selectedIndex==0){
			alert("Debe seleccionar la ACTIVIDAD.");
			document.all.txtActividad.focus();
			return false;
		}
		
		if (document.all.txtPorcentaje.value=='' || parseFloat(document.all.txtPorcentaje.value)<=0){
			alert("Debe capturar el campo PORCENTAJE.");
			document.all.txtPorcentaje.focus();
			return false;
		}		

		return true;		
	}
	
	function limpiarCampos(){
		document.all.txtSujeto.selectedIndex=0;
		document.all.txtObjeto.selectedIndex=0;
		document.all.txtAuditoria.selectedIndex=0;
		document.all.txtFase.selectedIndex=0;
		document.all.txtActividad.selectedIndex=0;
		document.all.txtPorcentaje.value='0.00';
	}
	
	var nUsr='<?php echo $_SESSION["idUsuario"];?>';
	var nCampana='<?php echo $_SESSION["idCuentaActual"];?>';
	  
	$(document).ready(function(){
		
		if(nUsr!="" && nCampana!=""){
			cargarMenu( nCampana);			
		}else{
			if(nCampana=="")alert("Debe establecer una CUENTA PÚBLICA como PREDETERMINADA. Por favor consulte con su administrador del sistema.");
		}

		
		
		recuperarLista('lstSujetos', document.all.txtSujeto);
	
		$( "#btnGuardarAvance" ).click(function() {
			if (validarAvance()){
				document.all.formulario.submit();
			}

		});
		
		$( "#btnLimpiarCampos" ).click(function() {	limpiarCampos();});
		
		
		$( "#btnAgregarAvance" ).click(function() {
			$('#modalAvance').removeClass("invisible");
			$('#modalAvance').modal('toggle');
			$('#modalAvance').modal('show');
			document.all.txtOperacion.value='INS'
		});
		
		
		
	
	});
	
	
	
	function recuperarAuditorias(){
		var param="";
		if (document.all.txtSujeto.selectedIndex>0 && document.all.txtObjeto.selectedIndex>0){	
		
			param = ""  + document.all.txtSujeto.options[document.all.txtSujeto.selectedIndex].value;

			param = param + "/"  +  document.all.txtObjeto.options[document.all.txtObjeto.selectedIndex].value;

			//alert("Parametros: " + param );

			recuperarListaLigada('lstAuditoriasBySujetoObjeto', param, document.all.txtAuditoria);
		}
	}
	
	
	
	function recuperarActividades(){
		var param="";
		if (document.all.txtAuditoria.selectedIndex>0 && document.all.txtFase.selectedIndex>0){			
			param = ""  + document.all.txtAuditoria.options[document.all.txtAuditoria.selectedIndex].value;
			param = param + "/"  +  document.all.txtFase.options[document.all.txtFase.selectedIndex].value;
			//alert("Parametros: " + param );
			recuperarListaLigada('lstActividadesByAuditoriaFase', param, document.all.txtActividad);
		}
	}
	
	
	
    </script>
  
  
  <!-- Title and other stuffs -->
  <title>Sistema Integral de Auditorias</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="keywords" content="">
  <meta name="author" content="">

  <!-- Stylesheets -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <!-- Font awesome icon -->
  <link rel="stylesheet" href="css/font-awesome.min.css"> 
  <!-- jQuery UI -->
  <link rel="stylesheet" href="css/jquery-ui.css"> 
  <!-- Calendar -->
  <link rel="stylesheet" href="css/fullcalendar.css">
  <!-- prettyPhoto -->
  <link rel="stylesheet" href="css/prettyPhoto.css">  
  <!-- Star rating -->
  <link rel="stylesheet" href="css/rateit.css">
  <!-- Date picker -->
  <link rel="stylesheet" href="css/bootstrap-datetimepicker.min.css">
  <!-- CLEditor -->
  <link rel="stylesheet" href="css/jquery.cleditor.css"> 
  <!-- Data tables -->
  <link rel="stylesheet" href="jquery.dataTables.css"> 
  <!-- Bootstrap toggle -->
  <link rel="stylesheet" href="css/jquery.onoff.css">
  <!-- Main stylesheet -->
  <link href="css/style-dashboard.css" rel="stylesheet">
  <!-- Widgets stylesheet -->
  <link href="css/widgets.css" rel="stylesheet">   
  
  <script src="./Dashboard - MacAdmin_files/respond.min.js"></script>
  <!--[if lt IE 9]>
  <script src="js/html5shiv.js"></script>
  <![endif]-->

  <!-- Favicon -->
  <link rel="shortcut icon" href="img/favicon.png">
<body>
    <nav class="navbar navbar-default navbar-fixed-top">
		<div class="container-fluid">
			<nav class="collapse navbar-collapse bs-navbar-collapse" role="navigation">			
				<div class="col-xs-12">
					<div class="col-xs-2"><a href="/"><img src="img/logo-top.png"></a></div>				
					<div class="col-xs-2">
						<ul class="nav navbar-nav "><li><a href="#"><i class="fa fa-th-list"></i> <?php echo $_SESSION["sCuentaActual"] ?></a></li></ul>
					</div>					
					<div class="col-xs-3"><h2>Avances por Auditoría</h2></a></div>									
					<div class="col-xs-2">
						<ul class="nav navbar-nav "><li><a href="./notificaciones"><i class="fa fa-envelope-o"></i> Usted tiene <span class="badge">0</span> Mensaje(s).</a></li></ul>
					</div>					
					<div class="col-xs-3">
						<ul class="nav navbar-nav  pull-right">
							<li class="dropdown pull-right">            
								<a data-toggle="dropdown" class="dropdown-toggle" href="/">
									<i class="fa fa-user"></i> <b>C. <?php echo $_SESSION["sUsuario"] ?></b> <b class="caret"></b> 							
								</a>
								<ul class="dropdown-menu">
								  <li><a href="./perfil"><i class="fa fa-user"></i> Perfil</a></li>
								  <li><a href="./cerrar"><i class="fa fa-sign-out"></i> Salir</a></li>
								</ul>
							</li>
						</ul>								
					</div>				
				</div>
			</nav>
		</div>
	</nav>
	<header></header>


<!-- Main content starts -->

<div class="content">
  	<!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-dropdown"><a href="/">Navigation</a></div>
		<!--- Sidebar navigation -->
		<ul id="nav">
		  <li class="has_sub"><a href="/"><i class="fa fa-home"></i> Inicio</a></li>
		  
		  <li class="has_sub"  id="GESTION" style="display:none;">
			<a href=""><i class="fa fa-pencil-square-o"></i> Gestión<span class="pull-right"><i class="fa fa-chevron-right"></i></span></a>
			<ul id="GESTION-UL"></ul>
		  </li>
		  
		  <li class="has_sub"  id="PROGRAMA" style="display:none;">
			<a href=""><i class="fa fa-bars"></i> Programas<span class="pull-right"><i class="fa fa-chevron-right"></i></span></a>
			<ul id="PROGRAMA-UL"></ul>
		  </li>

		  <li class="has_sub"  id="AUDITORIA" style="display:none;">
			<a href=""><i class="fa fa-search"></i> Auditorías<span class="pull-right"><i class="fa fa-chevron-right"></i></span></a>
			<ul id="AUDITORIA-UL"></ul>
		  </li>
		  
		  <li class="has_sub"  id="OBSERVACIONES" style="display:none;">
			<a href=""><i class="fa fa-cogs"></i> Acciones<span class="pull-right"><i class="fa fa-chevron-right"></i></span></a>
			<ul id="OBSERVACIONES-UL"></ul>
		  </li>
		  
		  <li class="has_sub"  id="CONFIGURACION" style="display:none;">
			<a href=""><i class="fa fa-pencil-square-o"></i> Catálogos<span class="pull-right"><i class="fa fa-chevron-right"></i></span></a>
			<ul id="CONFIGURACION-UL"></ul>
		  </li>
		  

		  <li class="has_sub"  id="REPORTEADOR" style="display:none;">
			<a href=""><i class="fa fa-file-text-o"></i> Informes<span class="pull-right"><i class="fa fa-chevron-right"></i></span></a>
			<ul id="REPORTEADOR-UL"></ul>
		  </li>	
		  
		  <li class="has_sub"><a href="/cerrar"><i class="fa fa-sign-out"></i> Salir</a></li>		  
		  
		</ul>
	</div> <!-- Sidebar ends -->

  	  	<!-- Main bar -->
  	<div class="mainbar">
					<div class="row">
						<div class="col-xs-12">
							<div class="widget">
								<div class="widget-head">
								  <div class="pull-left"><h3 class="modal-title"><i class="fa fa-tasks"></i> Avance de Actividades por Auditoría</h3></div>
								  <div class="widget-icons pull-right">
									<button type="button" class="btn btn-primary active btn-xs" 	id="btnAgregarAvance"><i class="fa fa-floppy-o"></i> Agregar Avance</button>
								  </div>  
								  <div class="clearfix"></div>
								</div>             
								<div class="widget-content">
									<div class="form-group">							
										<div class="col-xs-6"><div id="canvasJG" ></div></div>						
										<div class="col-xs-6"><div id="canvasJD" ></div></div>
									</div>
									<div class="clearfix"></div>								
									<div class="table-responsive" style="height: 300px; overflow: auto; overflow-x:hidden;">
										<table class="table table-striped table-bordered table-hover table-condensed">
										  <thead>
											<tr><th>Clave Auditoría</th><th>Sujeto de Fiscalización</th><th>Objeto de Fiscalización</th><th>Tipo de Auditoría</th><th>ID Avance</th><th>Fecha Avance</th><th>Fase</th><th>Actividad</th><th>Porcentaje</th><th>Estatus</th></tr>
										  </thead>
										  <tbody>				

											<?php foreach($datos as $key => $valor): ?>
											<tr onclick=<?php echo "javascript:alert('CONSTRUCCION');"; ?> style="width: 100%; font-size: xx-small">										  										  
											  <td><?php echo $valor['auditoria']; ?></td>
											  <td><?php echo $valor['sujeto']; ?></td>
											  <td><?php echo $valor['objeto']; ?></td>
											  <td><?php echo $valor['tipo']; ?></td>
											  <td><?php echo $valor['avance']; ?></td>
											  <td><?php echo $valor['fechaAvance']; ?></td>
											  <td><?php echo $valor['fase']; ?></td>
											  <td><?php echo $valor['porcentaje']; ?></td>
											  <td><?php echo $valor['actividad']; ?></td>
											  <td><?php echo $valor['estatus']; ?></td>
											</tr>
											<?php endforeach; ?>
																						
										  </tbody>
										</table>
									</div>
								</div>
								<div class="widget-foot">
								</div>
							</div>				
						</div>
					</div>
				
	</div>			
</div>


<div id="modalAvance" class="modal fade" role="dialog">
		<div class="modal-dialog">							
				<!-- Modal content-->
			<div class="modal-content">									
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h2 class="modal-title"><i class="fa fa-users"></i> Registrar Actividad por Auditoría...</h2>
				</div>									
				<div class="modal-body">
							<form id="formulario" METHOD='POST' ACTION="/guardar/avance" role="form">
								<input type='HIDDEN' name='txtOperacion' value=''>
								<input type='HIDDEN' name='txtCuenta' value=''>						
								<input type='HIDDEN' name='txtPrograma' value=''>	
								<br>
								<div class="form-group">
									<label class="col-xs-2 control-label">Sujeto</label>
									<div class="col-xs-10">
										<select class="form-control" name="txtSujeto" onChange="recuperarListaLigada('lstObjetosBySujeto', this.value, document.all.txtObjeto);">
											<option value="">Seleccione...</option>											
										</select>
									</div>
								</div>	
								<br>
								<div class="form-group">									
									<label class="col-xs-2 control-label">Objeto</label>
									<div class="col-xs-10">
										<select class="form-control" name="txtObjeto" onChange="recuperarAuditorias();">
											<option value="">Seleccione</option>
										</select>
									</div>	
								</div>									
								<br>
								<div class="form-group">									
									<label class="col-xs-2 control-label">Auditoría</label>
									<div class="col-xs-5">
										<select class="form-control" name="txtAuditoria">
											<option value="">Seleccione</option>
										</select>
									</div>	
										
									<label class="col-xs-1 control-label">Fase</label>
									<div class="col-xs-4">
										<select class="form-control" name="txtFase" onchange="recuperarActividades();">
											<option value="" Selected>Seleccione...</option>
											<option value="PLANEACION">PLANEACIÓN</option>
											<option value="EJECUCIÓN">EJECUCIÓN</option>
											<option value="INFORMES">ELABORACIÓN DE INFORMES</option>
										</select>
									</div>
								</div>	
								<br>							
								<div class="form-group">							
									<label class="col-xs-2 control-label">Actividad</label>
									<div class="col-xs-10">
										<select class="form-control" name="txtActividad">
											<option value="">Seleccione...</option>
										</select>
									</div>																		
								</div>			
								<br>
								<div class="form-group">								
									<label class="col-xs-2 control-label">Porcentaje</label>
									<div class="col-xs-2">
										<input type="number" min="0" max="100" value='0.00' step="5" class="form-control" name="txtPorcentaje"/>
									</div>										
									<label class="col-xs-8 control-label"></label>
								</div>								
								<br>	
								<div class="clearfix"></div>
							</form>
					<div class="clearfix"></div>
				</div>
				
				<div class="modal-footer">
					<div class="pull-right">
						<button type="button" class="btn btn-primary active" 	id="btnGuardarAvance"><i class="fa fa-floppy-o"></i> Guardar</button>
						<button type="button" class="btn btn-default active" 	id="btnLimpiarCampos"><i class="fa fa-eraser"></i> Limpiar campos</button>
						<button type="button" class="btn btn-default active" 	id="btnCancelarAvance"><i class="fa fa-back"></i> Cancelar</button>
					</div>
					<div class="clearfix"></div>
				</div>
			</div>		
		</div>
	</div>




<!-- Content ends -->


<!-- Footer starts -->
<footer>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
            <!-- Copyright info -->
		<p class="copy">Copyright © 2016 | Auditoría Superior de la Ciudad de México</p>
      </div>
    </div>
  </div>
</footer> 	

<!-- Footer ends -->

<!-- Scroll to top -->
<span class="totop" style="display: none;"><a href="#"><i class="fa fa-chevron-up"></i></a></span> 

<!-- JS -->
<script src="./Dashboard - MacAdmin_files/jquery.js"></script> <!-- jQuery -->
<script src="./Dashboard - MacAdmin_files/bootstrap.min.js"></script> <!-- Bootstrap -->
<script src="./Dashboard - MacAdmin_files/jquery-ui.min.js"></script> <!-- jQuery UI -->
<script src="./Dashboard - MacAdmin_files/moment.min.js"></script> <!-- Moment js for full calendar -->
<script src="./Dashboard - MacAdmin_files/fullcalendar.min.js"></script> <!-- Full Google Calendar - Calendar -->
<script src="./Dashboard - MacAdmin_files/jquery.rateit.min.js"></script> <!-- RateIt - Star rating -->
<script src="./Dashboard - MacAdmin_files/jquery.prettyPhoto.js"></script> <!-- prettyPhoto -->
<script src="./Dashboard - MacAdmin_files/jquery.slimscroll.min.js"></script> <!-- jQuery Slim Scroll -->
<script src="./Dashboard - MacAdmin_files/jquery.dataTables.min.js"></script> <!-- Data tables -->

<!-- jQuery Flot -->
<script src="./Dashboard - MacAdmin_files/excanvas.min.js"></script>
<script src="./Dashboard - MacAdmin_files/jquery.flot.js"></script>
<script src="./Dashboard - MacAdmin_files/jquery.flot.resize.js"></script>
<script src="./Dashboard - MacAdmin_files/jquery.flot.pie.js"></script>
<script src="./Dashboard - MacAdmin_files/jquery.flot.stack.js"></script>

<!-- jQuery Notification - Noty -->
<script src="./Dashboard - MacAdmin_files/jquery.noty.js"></script> <!-- jQuery Notify -->
<script src="./Dashboard - MacAdmin_files/default.js"></script> <!-- jQuery Notify -->
<script src="./Dashboard - MacAdmin_files/bottom.js"></script> <!-- jQuery Notify -->
<script src="./Dashboard - MacAdmin_files/topRight.js"></script> <!-- jQuery Notify -->
<script src="./Dashboard - MacAdmin_files/top.js"></script> <!-- jQuery Notify -->
<!-- jQuery Notification ends -->

<script src="./Dashboard - MacAdmin_files/sparklines.js"></script> <!-- Sparklines -->
<script src="./Dashboard - MacAdmin_files/jquery.cleditor.min.js"></script> <!-- CLEditor -->
<script src="./Dashboard - MacAdmin_files/bootstrap-datetimepicker.min.js"></script> <!-- Date picker -->
<script src="./Dashboard - MacAdmin_files/jquery.onoff.min.js"></script> <!-- Bootstrap Toggle -->
<script src="./Dashboard - MacAdmin_files/filter.js"></script> <!-- Filter for support page -->
<script src="./Dashboard - MacAdmin_files/custom.js"></script> <!-- Custom codes -->
<script src="./Dashboard - MacAdmin_files/charts.js"></script> <!-- Charts & Graphs -->

</body></html>


