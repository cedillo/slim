var bEncontrado;


	function cargarMenu(sCampana){
		var sPanel ="";
		var nRenglon=0;
		var nTotal=0;
		var dato;
		
		$.ajax({
			type: 'GET',
			url: '/lstModulosByUsuarioCampana/' + sCampana,
			success: function(response) {
				var jsonData = JSON.parse(response);				
				nTotal =jsonData.datos.length;
				
				for (var i = 0; i < jsonData.datos.length; i++) {
					dato = jsonData.datos[i];
					//modulos.push(dato.tipo, dato.panel, dato.modulo);
					
					sPanel = dato.panel;
					document.getElementById(sPanel).style.display="block";
					
					sPanel = sPanel + "-UL";

 					var ul = document.getElementById(sPanel);
						var li = document.createElement("li");						
							var ancla = document.createElement('a');							
							ancla.setAttribute('href', dato.liga);
								//PARA CARGAR UN ICONO
								//var li2 = document.createElement("li");
								//li2.setAttribute("class", "fa fa-sitemap");							
								//ancla.appendChild(li2);								
								var texto = document.createTextNode( " " + dato.nombre);
								ancla.appendChild(texto);								
							nRenglon = nRenglon+1;							
						li.appendChild(ancla);
					ul.appendChild(li); 
				}
			},
			error: function(xhr, textStatus, error){
				alert('ERROR: En function cargarMenu(sCampana)  ->  statusText: ' + xhr.statusText + ' TextStatus: ' + textStatus + ' Error:' + error );
			}			
		});		
	}
	
	





// ***********************************  
	function recuperarLista(lista, cmb){
		//alert("Recuperando Lista: " + lista);
		$.ajax({
				type: 'GET', url: '/'+ lista  ,
				success: function(response) {
					var jsonData = JSON.parse(response);
					
					//alert("Registros recuperados:" + jsonData.datos.length);

					//Vacia la lista
					while (cmb.length>1){
						cmb.remove(cmb.length-1);
					}
						
					//Agregar elementos
					for (var i = 0; i < jsonData.datos.length; i++) {
						var dato = jsonData.datos[i];
						var option = document.createElement("option");
						option.text = dato.texto;
						option.value = dato.id;
						cmb.add(option, i+1);
					}				
				},
				error: function(xhr, textStatus, error){
					alert("ERROR EN: function recuperarLista(lista, cmb)" + " Donde lista=" + lista );
				}			
			});	
	} 
	
// ***********************************  
	function recuperarListaLigada(lista, valor, cmb){
		$.ajax({
			type: 'GET', url: '/'+ lista + '/' + valor ,
			success: function(response) {
				var jsonData = JSON.parse(response);
			
				//Vacia la lista
				while (cmb.length>1){
					cmb.remove(cmb.length-1);
				}
					
				//Agregar elementos
				for (var i = 0; i < jsonData.datos.length; i++) {
					var dato = jsonData.datos[i];
					var option = document.createElement("option");
					option.text = dato.texto;
					option.value = dato.id;
					cmb.add(option, i+1);
				}				
			},
			error: function(xhr, textStatus, error){
				alert("ERROR EN: function recuperarListaLigada(lista, valor, cmb)" + " Donde lista=" + lista );
			}			
		});	
	}

// ***********************************  
	function recuperarListaSelected(lista, parametro, cmb, id ){
		$.ajax({
			type: 'GET', url: '/'+ lista + '/' + parametro ,
			success: function(response) {
				var jsonData = JSON.parse(response);
			
				//Vacia la lista
				while (cmb.length>1){
					cmb.remove(cmb.length-1);
				}
					
				//Agregar elementos
				for (var i = 0; i < jsonData.datos.length; i++) {
					var dato = jsonData.datos[i];
					var option = document.createElement("option");
					option.text = dato.texto;
					option.value = dato.id;
					if (dato.id==id) option.selected = true;
					cmb.add(option, i+1);
				}				
			},
			error: function(xhr, textStatus, error){
				alert("ERROR EN: function recuperarListaLigada(lista, parametro, cmb, id)" + " Donde lista=" + lista );
			}			
		});	
	}	
	
	// ***********************************  
		function recuperarTablaLigada(lista, valor, tbl){
		$.ajax({
			type: 'GET', url: '/'+ lista + '/' + valor ,
			success: function(response) {
				var jsonData = JSON.parse(response);			
				
				//Vacia la lista
				tbl.innerHTML="";
					
				//Agregar renglones
				var renglon, columna;
				for (var i = 0; i < jsonData.datos.length; i++) {
					var dato = jsonData.datos[i];
					renglon=document.createElement("TR");				
					renglon.innerHTML="<td>" + dato.distrito + "</td><td>" + dato.idSeccion + "</td><td>" + dato.idCasilla + "</td>	<td>" + dato.representante + "</td><td>" + dato.acreditado + "</td><td>" + dato.estatus + "</td>";
					renglon.onclick= function() {
						obtenerDatosCasilla(dato.idSeccion , dato.idCasilla ); 
					};
					tbl.appendChild(renglon);					
				}				
			},
			error: function(xhr, textStatus, error){
				alert("ERROR EN: function recuperarTablaLigada(lista, valor, tbl)" + " Donde lista=" + lista );
			}			
		});	
	}
	
	
	
	// ***********************************  
	

	function seleccionarElemento(cmb, value){		
		var nPosicion;
		nPosicion=0;
		bEncontrado=false;
		
		for(var i=0; i < cmb.options.length; i++){
			
			if(cmb[i].value == value) {
				cmb.selectedIndex = i;
				bEncontrado=true;
				nPosicion=i;
			}
		}
		
		if (bEncontrado==false){
			//alert("El Elemento " + value + " no se encontro en la lista.");
			cmb.selectedIndex = 0;
		}else{
			cmb.selectedIndex = nPosicion;
		}
		
  } 



	
	
	